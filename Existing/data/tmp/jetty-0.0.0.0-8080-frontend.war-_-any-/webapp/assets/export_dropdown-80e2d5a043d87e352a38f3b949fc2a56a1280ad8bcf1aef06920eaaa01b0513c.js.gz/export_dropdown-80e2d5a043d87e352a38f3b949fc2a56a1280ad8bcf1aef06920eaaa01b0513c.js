$(function () {
  $(document).on("loadedrecordform.aspace", function(event) {

    // allow option sidebar to stay open when
    // elements are clicked
    $('.record-toolbar').on('change click keyup', '.dropdown-submenu input', function(e) {
      e.stopPropagation();
    });
    $('.record-toolbar').on('click', 'a.download-ead-action', function(e) {
      var url = AS.quickTemplate(decodeURIComponent($("#download-ead-dropdown").data("download-ead-url")), { testme: true,  include_unpublished: $("input#include-unpublished").is(':checked'), include_daos: $("input#include-daos").is(':checked'), numbered_cs: $("input#numbered-cs").is(':checked'), print_pdf: $("input#print-pdf").is(':checked'), ead3: $("input#ead3").is(':checked')});
      location.href = url;
    });
    $('.record-toolbar').on('click', 'a.download-marc-action', function(e) {
      var url = AS.quickTemplate(decodeURIComponent($("#download-marc-dropdown").data("download-marc-url")), {  include_unpublished_marc: $("input#include-unpublished-marc").is(':checked')});
      console.log(url);
      location.href = url;
    });
    $('.record-toolbar').on('click', 'a.download-mets-action', function(e) {
      var url = AS.quickTemplate(decodeURIComponent($("#download-mets-dropdown").data("download-mets-url")), {  dmd_scheme: $("input#js-dmd_scheme_mods").is(':checked') ? "mods" : "dc"});
      console.log(url);
      location.href = url;
    });
  });

});
